package Clock;

public class MyFrame {
}
