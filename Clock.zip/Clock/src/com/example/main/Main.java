package com.example.main;

import Clock.MyFrame;

public class Main {
    public static void main(String [] args) {

        new MyFrame();
    }
}
